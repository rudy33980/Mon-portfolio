export { default } from './scripts/Main';
